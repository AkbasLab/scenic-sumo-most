"""Support for file formats not specific to particular simulators.

.. raw:: html

   <h2>Submodules</h2>

.. autosummary::
   :toctree:

   opendrive
"""
