"""The Scenic compiler and associated support code.

.. raw:: html

   <h2>Submodules</h2>

.. autosummary::
   :toctree:

   relations
   translator
   veneer
"""

