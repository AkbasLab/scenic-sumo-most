"""World model for a simple Mars rover example in Webots.

.. raw:: html

   <h2>Submodules</h2>

.. autosummary::
   :toctree:

   model
"""

